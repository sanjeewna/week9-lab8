import React from 'react'

function faq1() {
  return (
    <div>
        <h3>#1 What is Backroads?</h3>
        <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque vitae tempore voluptatum maxime reprehenderit eum quod exercitationem fugit, qui corporis.
         </p> 
         <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque vitae tempore voluptatum maxime reprehenderit eum quod exercitationem fugit, qui corporis.
         </p>     
    </div>
  )
}

export default faq1