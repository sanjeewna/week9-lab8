import React from 'react'

function faq4() {
  return (
    <div>
        <h3>#3 How to join at Backroads?</h3>
        <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque vitae tempore voluptatum maxime reprehenderit eum quod exercitationem fugit, qui corporis.
         </p> 
       
         <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque vitae tempore voluptatum maxime reprehenderit eum quod exercitationem fugit, qui corporis.
         </p> 
        
    </div>
  )
}

export default faq4