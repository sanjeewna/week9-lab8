import React from 'react'

function faq3() {
  return (
    <div>
        <h3>#3 How is Backroads?</h3>
        <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque vitae tempore voluptatum maxime reprehenderit eum quod exercitationem fugit, qui corporis.
         </p> 
       
         <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque vitae tempore voluptatum maxime reprehenderit eum quod exercitationem fugit, qui corporis.
         </p> 
         <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque vitae tempore voluptatum maxime reprehenderit eum quod exercitationem fugit, qui corporis.
         </p>     
    </div>
  )
}

export default faq3