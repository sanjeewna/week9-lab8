import React from 'react'

function NotFound() {
  return (
    <div className='not__found__wrapper'>
        <h1>Page Not Found!</h1>
    </div>
  )
}

export default NotFound